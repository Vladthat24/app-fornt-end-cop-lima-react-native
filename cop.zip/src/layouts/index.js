//exportar nuestro component
export * from "./ClientLayout";
export * from "./AdminLayout";
export * from "./BasicLayout";
