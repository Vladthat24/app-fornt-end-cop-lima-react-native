export * from './RegistroTablesAdmin';
