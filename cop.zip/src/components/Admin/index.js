export * from "./LoginForm";
export * from "./HeaderPage";
export * from "./SideMenu";
export * from "./TopMenu";

export * from "./Users";
export * from "./Category";
export * from "./Product";
export * from "./Table";
export * from "./TableDetails";
export * from "./Orders";
export * from "./Payments";
export * from "./Registro";
/* export * from "./Paginacion"; */
