import React from "react";
import { Card, Grid } from "semantic-ui-react";

export function ListadoColegiado() {
  return (
    <>
      <Grid columns={4}>
        <Grid.Column>
          <Card>
            <Card.Content>Hola </Card.Content>
          </Card>
        </Grid.Column>
        <Grid.Column>
          <Card>
            <Card.Content>Hola </Card.Content>
          </Card>
        </Grid.Column> 
        <Grid.Column>
          <Card>
            <Card.Content>Hola </Card.Content>
          </Card>
        </Grid.Column>
        <Grid.Column>
          <Card>
            <Card.Content>Hola </Card.Content>
          </Card>
        </Grid.Column>
        <Grid.Column>
          <Card>
            <Card.Content>Hola </Card.Content>
          </Card>
        </Grid.Column>
        <Grid.Column>
          <Card>
            <Card.Content>Hola </Card.Content>
          </Card>
        </Grid.Column>
        <Grid.Column>
          <Card>
            <Card.Content>Hola </Card.Content>
          </Card>
        </Grid.Column>
        <Grid.Column>
          <Card>
            <Card.Content>Hola </Card.Content>
          </Card>
        </Grid.Column>
        <Grid.Column>
          <Card>
            <Card.Content>Hola </Card.Content>
          </Card>
        </Grid.Column>
      </Grid>
    </>
  );
}
